import express from 'express';
import Item from '../models/Item.js';

class ItemController {
  static async addItem(req, res) {
    try {
      const newItem = new Item(); // Instantiate the model
      newItem.table = 'shopping.items'; // Set the table name
      newItem.name = req.body.name;
      newItem.quantity = req.body.quantity;
      
      // Save the new item
      await newItem.save();

      res.status(200).send('Item added successfully.');
    } catch (error) {
      console.error('Error adding item:', error);
      res.status(500).send('Failed to add item');
    }
  }

  static async getAllItems(req, res) {
    try {
      const allItems = new Item(); // Instantiate the model
      allItems.table = 'shopping.items'; // Set the table name

      // Load all items
      const items = await allItems.loadMany();

      // Render or send items as needed
      res.render('items', { items }); // Adjust for your rendering logic
    } catch (error) {
      console.error('Error fetching items:', error);
      res.status(500).send('Failed to fetch items');
    }
  }

  static async deleteItem(req, res) {
    try {
      const itemToDelete = new Item(); // Instantiate the model
      itemToDelete.table = 'shopping.items'; // Set the table name
      const itemId = req.params.id; // Assuming the item ID is passed in the URL

      // Delete item by ID
      await itemToDelete.delete({ id: itemId });

      res.status(200).send('Item deleted successfully.');
    } catch (error) {
      console.error('Error deleting item:', error);
      res.status(500).send('Failed to delete item');
    }
  }
}

export default ItemController;
