// app.js
import express from 'express';
import routes from './routes.js';

const app = express();
app.use(express.urlencoded({ extended: true }));
app.set('view engine', 'ejs'); // Assuming you're using EJS for views
app.use('/', routes);

app.listen(3000, () => {
  console.log('Server running on port 3000');
});
