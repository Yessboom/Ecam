// routes.js
import express from 'express';
import itemController from './controllers/itemController.js';

const router = express.Router();

router.get('/', itemController.getAllItems);
router.post('/add', itemController.addItem);
router.get('/delete/:id', itemController.deleteItemById);

export default router;
