// models/Item.js
import Model from './Model.js';

class Item extends Model {
  static table = 'shopping.items';
  static primary = ['id_item'];

  constructor() {
    super();
    this.id_item = null;
    this.name = '';
    this.quantity = '';
    this.purchased = null;
  }

  // ... other methods remain the same

  async addItem(itemData) {
    try {
      this.name = itemData.name;
      this.quantity = itemData.quantity;
      await this.save();
    } catch (error) {
      throw error;
    }
  }
}

export default Item;
